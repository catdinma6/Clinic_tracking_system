<header>
                <div class="header">
                    <img src="assets/image1.jpg">
                   
                    <div class="dropdown">
                        <button class="dropbtn"><?php echo ucwords($userinfo->name) ?></button>
                        <div class="dropdown-content">
                        <a href = "../logout.php">Logout</a>
                        <a href = "cpassword.php">Change Password</a>
                        
                      </div>
                      </div>
                   </div> 
                
        </header>
        